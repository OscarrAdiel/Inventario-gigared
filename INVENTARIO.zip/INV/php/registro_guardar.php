<?php
require_once "main.php";

// Definimos que este script SIEMPRE responderá con JSON
header('Content-Type: application/json');

try {
    /*== Almacenando datos ==*/
    $nombre = limpiar_cadena($_POST['usuario_nombre']);
    $email = limpiar_cadena($_POST['usuario_email']);
    $clave_1 = limpiar_cadena($_POST['usuario_clave_1']);
    $clave_2 = limpiar_cadena($_POST['usuario_clave_2']);

    /*== Verificando campos obligatorios ==*/
    if ($nombre == "" || $email == "" || $clave_1 == "" || $clave_2 == "") {
        throw new Exception("No has llenado todos los campos que son obligatorios");
    }

    /*== Verificando integridad de los datos ==*/
    if (verificar_datos("[a-zA-ZáéíóúÁÉÍÓÚñÑ ]{3,100}", $nombre)) {
        throw new Exception("El Nombre no coincide con el formato solicitado");
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        throw new Exception("El Email ingresado no es válido");
    }
    if (verificar_datos("[a-zA-Z0-9$@.-]{8,100}", $clave_1)) {
        throw new Exception("La Contraseña no coincide con el formato solicitado");
    }
    if ($clave_1 != $clave_2) {
        throw new Exception("Las contraseñas no coinciden");
    }

    $pdo = conexion();

    /*== Verificando si el email ya existe ==*/
    $check_email = $pdo->prepare("SELECT email FROM usuarios WHERE email = :email");
    $check_email->execute([':email' => $email]);
    if ($check_email->rowCount() > 0) {
        throw new Exception("El Email que intentas registrar ya se encuentra en uso");
    }
    
    /*== Encriptando la contraseña ==*/
    // NUNCA guardes contraseñas en texto plano
    $hash_clave = password_hash($clave_1, PASSWORD_DEFAULT);

    /*== Guardando datos ==*/
    // El rol se guarda como 'usuario' por defecto
    $guardar_usuario = $pdo->prepare(
        "INSERT INTO usuarios(nombre, email, contrasena, rol) 
         VALUES(:nombre, :email, :pass, 'usuario')"
    );

    $marcadores = [
        ":nombre" => $nombre,
        ":email" => $email,
        ":pass" => $hash_clave
    ];

    $guardar_usuario->execute($marcadores);

    if ($guardar_usuario->rowCount() == 1) {
        $response = [
            "success" => true,
            "message" => "¡Te has registrado exitosamente!",
            "redirect" => "index.php?vista=home" // Redirige al login
        ];
    } else {
        throw new Exception("No se pudo registrar el usuario, por favor intente nuevamente");
    }

} catch (Exception $e) {
    // Si algo falla, se captura el error aquí
    $response = [
        "success" => false,
        "message" => $e->getMessage()
    ];
}

// Se imprime la respuesta JSON final
echo json_encode($response);
$pdo = null;
?>