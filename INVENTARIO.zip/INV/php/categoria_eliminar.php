<?php
require_once "main.php"; // Asegúrate de incluir tus funciones principales

// Definir la URL base para la redirección
$redirect_url = "../index.php?vista=category_list";

/*== Almacenando id ==*/
$category_id_del = limpiar_cadena($_GET['category_id_del']);

$pdo = conexion();

/*== Verificacion si la categoria tiene productos asociados ==*/
$check_productos = $pdo->prepare("SELECT categoria_id FROM producto WHERE categoria_id = :id LIMIT 1");
$check_productos->execute([':id' => $category_id_del]);

if ($check_productos->rowCount() <= 0) {
    // No tiene productos, se puede eliminar

    /*== Eliminando categoria ==*/
    $eliminar_categoria = $pdo->prepare("DELETE FROM categoria WHERE categoria_id = :id");
    $eliminar_categoria->execute([":id" => $category_id_del]);

    if ($eliminar_categoria->rowCount() == 1) {
        // Éxito al eliminar
        header("Location: " . $redirect_url . "&cat_deleted=ok");
        exit();
    } else {
        // Error al eliminar (por si acaso, aunque es raro si pasó el check inicial)
        header("Location: " . $redirect_url . "&cat_deleted=error");
        exit();
    }
} else {
    // Tiene productos asociados, no se puede eliminar
    header("Location: " . $redirect_url . "&cat_deleted=has_products");
    exit();
}

$pdo = null; // Cerrar conexión
?>