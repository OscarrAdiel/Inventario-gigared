<?php
// Requerimos el session_start() primero para poder manejar las sesiones
require_once "../inc/session_start.php"; 
require_once "main.php";

// Definimos que este script SIEMPRE responderá con JSON
header('Content-Type: application/json');

try {
    /*== Almacenando datos ==*/
    $email = limpiar_cadena($_POST['login_email']);
    $clave = limpiar_cadena($_POST['login_clave']);

    /*== Verificando campos obligatorios ==*/
    if ($email == "" || $clave == "") {
        throw new Exception("No has llenado todos los campos que son obligatorios");
    }

    /*== Verificando integridad de los datos ==*/
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        throw new Exception("El Email ingresado no es válido");
    }
    if (verificar_datos("[a-zA-Z0-9$@.-]{8,100}", $clave)) {
        throw new Exception("La Contraseña no coincide con el formato solicitado");
    }

    $pdo = conexion();

    /*== Verificando si el email existe ==*/
    $check_user = $pdo->prepare("SELECT * FROM usuarios WHERE email = :email");
    $check_user->execute([':email' => $email]);

    if ($check_user->rowCount() == 1) {
        $usuario = $check_user->fetch(PDO::FETCH_ASSOC);

        
        if ($clave == $usuario['contrasena']) {
            
            
            $_SESSION['id'] = $usuario['usuario_id'];
            $_SESSION['nombre'] = $usuario['nombre'];
            $_SESSION['rol'] = $usuario['rol']; 

            $response = [
                "success" => true,
                "message" => "¡Bienvenido, " . $usuario['nombre'] . "!",
                "redirect" => "index.php?vista=home" 
            ];

        } else {
            
            throw new Exception("Email o contraseña incorrectos");
        }

    } else {
        
        throw new Exception("Email o contraseña incorrectos");
    }

} catch (Exception $e) {
    
    $response = [
        "success" => false,
        "message" => $e->getMessage()
    ];
}


echo json_encode($response);
$pdo = null;
?>