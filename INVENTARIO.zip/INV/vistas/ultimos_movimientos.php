<div class="container is-fluid mb-6">
    <h1 class="title">Control de Movimientos</h1>
    <h2 class="subtitle">Bitácora de actividades del inventario</h2>
</div>

<div class="container pb-6 pt-6">
    <?php
        require_once "./php/main.php";

        $pagina = isset($_GET['page']) ? (int)$_GET['page'] : 1;
        $inicio = ($pagina>0) ? (($pagina * 20)-20) : 0;
        $registros = 20;
        
        $conexion = conexion();

        // Consulta compleja para traer nombre de usuario, producto y datos del historial
        $consulta = "
            SELECT h.*, u.nombre AS usuario_nombre, p.producto_nombre, p.producto_codigo
            FROM historial_productos h
            INNER JOIN usuarios u ON h.usuario_id = u.usuario_id
            LEFT JOIN producto p ON h.producto_id = p.producto_id
            ORDER BY h.fecha DESC
            LIMIT $inicio, $registros
        ";
        
        $conteo = $conexion->query("SELECT COUNT(historial_id) FROM historial_productos");
        $total = (int)$conteo->fetchColumn();
        $Npaginas = ceil($total/$registros);
        
        $historial = $conexion->query($consulta);
    ?>

    <div class="table-container">
        <table class="table is-bordered is-striped is-narrow is-hoverable is-fullwidth">
            <thead>
                <tr class="has-background-light">
                    <th class="has-text-centered">Fecha</th>
                    <th class="has-text-centered">Usuario</th>
                    <th class="has-text-centered">Acción Realizada</th>
                    <th>Producto</th>
                    <th>Detalles</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                if($historial->rowCount() > 0){
                    foreach($historial as $fila){
                        
                        // Colores dinámicos para las etiquetas
                        $clase_tag = "is-info";
                        $icono = "fa-info-circle";

                        if(strpos($fila['accion'], 'Venta') !== false){
                            $clase_tag = "is-success"; // Verde para ventas/salidas (o rojo si lo ves como pérdida de stock)
                            $icono = "fa-shopping-cart";
                        }
                        if(strpos($fila['accion'], 'Eliminar') !== false){
                            $clase_tag = "is-danger"; // Rojo para eliminar
                            $icono = "fa-trash";
                        }
                        if(strpos($fila['accion'], 'Actualiz') !== false){
                            $clase_tag = "is-warning"; 
                            
                            $icono = ""; // 1. Esto hace que la variable del icono quede vacía
                            $fila['accion'] = "Se actualizo"; //
                        }
                        if(strpos($fila['accion'], 'Crear') !== false){
                            $clase_tag = "is-primary"; // Azul para nuevos
                            $icono = "fa-plus-circle";
                        }
                ?>
                    <tr>
                        <td class="has-text-centered is-size-7">
                            <?php echo date("d/m/Y", strtotime($fila['fecha'])); ?><br>
                            <strong><?php echo date("h:i A", strtotime($fila['fecha'])); ?></strong>
                        </td>
                        <td class="has-text-centered">
                            <span class="icon-text">
                                <span class="icon"><i class="fas fa-user"></i></span>
                                <span><?php echo $fila['usuario_nombre']; ?></span>
                            </span>
                        </td>
                        <td class="has-text-centered">
                            <span class="tag <?php echo $clase_tag; ?> is-light">
                                <i class="fas <?php echo $icono; ?> mr-1"></i> 
                                <?php echo $fila['accion']; ?>
                            </span>
                        </td>
                        <td>
                            <strong><?php echo $fila['producto_nombre']; ?></strong><br>
                            <small class="has-text-grey">Cod: <?php echo $fila['producto_codigo']; ?></small>
                        </td>
                        <td class="is-size-7">
                            <?php echo $fila['detalles']; ?>
                        </td>
                    </tr>
                <?php 
                    }
                } else {
                ?>
                    <tr>
                        <td colspan="5" class="has-text-centered">No hay movimientos registrados aún.</td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>

    <?php 
        if($total>=1 && $pagina<=$Npaginas){
            echo paginador_tablas($pagina,$Npaginas,"index.php?vista=ultimos_movimientos&page=",7);
        }
    ?>
</div>