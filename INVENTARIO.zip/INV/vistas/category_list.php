<div class="container is-fluid mb-6">
    <h1 class="title">Categorías</h1>
    <h2 class="subtitle">Lista de categoría</h2>
</div>

<div class="container pb-6 pt-6">
    <?php
        require_once "./php/main.php";

        if(!isset($_GET['page'])){
            $pagina=1;
        }else{
            $pagina=(int) $_GET['page'];
            if($pagina<=1){
                $pagina=1;
            }
        }

        $pagina=limpiar_cadena($pagina);
        $url="index.php?vista=category_list&page=";
        $registros=15;
        $busqueda="";

        require_once "./php/categoria_lista.php";
    ?>

    <div class="modal" id="modalEliminar">
        <div class="modal-background"></div>
        <div class="modal-card">
            <header class="modal-card-head">
                <p class="modal-card-title">Confirmar eliminación</p>
                <button class="delete" aria-label="close" id="cerrarModal"></button>
            </header>
            <section class="modal-card-body">
                <p>¿Estás seguro de que deseas eliminar la categoría: <strong id="nombreCategoriaEliminar"></strong>?</p>
                <p class="has-text-danger has-text-weight-bold">Nota: Solo se puede eliminar si no tiene productos asociados.</p>
            </section>
            <footer class="modal-card-foot">
                <button class="button" id="cancelarEliminar">Cancelar</button>
                <a href="#" class="button is-danger" id="btnConfirmarEliminar">Eliminar</a>
            </footer>
        </div>
    </div>
</div>

<style>
  .modal-background {
    background-color: rgba(0, 0, 0, 0.3) !important;
  }
</style>


<script>
document.addEventListener('DOMContentLoaded', () => {

    // --- Elementos del Modal ---
    const modal = document.getElementById('modalEliminar');
    const botonCerrar = document.getElementById('cerrarModal');
    const botonCancelar = document.getElementById('cancelarEliminar');
    const fondoModal = document.querySelector('.modal-background');
    
    // --- Elementos clave para la función ---
    const textoNombreCategoria = document.getElementById('nombreCategoriaEliminar'); // ID del Paso 2
    const botonConfirmarEliminar = document.getElementById('btnConfirmarEliminar'); 
    const todosLosBotonesEliminar = document.querySelectorAll('.js-delete-button'); // Clase del Paso 1

    // --- Función para CERRAR el modal ---
    const cerrarModal = () => {
        modal.classList.remove('is-active');
    }
    botonCerrar.addEventListener('click', cerrarModal);
    botonCancelar.addEventListener('click', cerrarModal);
    fondoModal.addEventListener('click', cerrarModal);

    // --- Función para ABRIR el modal y pasar el nombre ---
    todosLosBotonesEliminar.forEach(boton => {
        boton.addEventListener('click', (e) => {
            e.preventDefault(); // Evita que la página salte
            
            // 1. Obtener datos del botón que clickeaste
            const id = boton.getAttribute('data-id');
            const nombre = boton.getAttribute('data-nombre');

            // 2. Poner el nombre en el modal
            textoNombreCategoria.textContent = nombre; 
            
            // 3. Poner el link correcto en el botón "Eliminar" del modal
            //    (¡¡IMPORTANTE: REVISA ESTA URL!!)
            botonConfirmarEliminar.href = `./php/categoria_eliminar.php?category_id_del=${id}`;

            // 4. Mostrar el modal
            modal.classList.add('is-active');
        });
    });

});
</script>

