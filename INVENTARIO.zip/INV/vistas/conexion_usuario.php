<?php
date_default_timezone_set('America/Tijuana');

require_once "./php/main.php";
$pdo = conexion();

$consulta = $pdo->query("SELECT usuario_id, nombre, email, rol, ultima_conexion FROM usuarios");
$usuarios = $consulta->fetchAll(PDO::FETCH_ASSOC);
?>

<h2 class="title">Lista de Usuarios</h2>

<table class="table is-fullwidth is-striped">
    <thead>
        <tr>
            <th>Nombre</th>
            <th>Email</th>
            <th>Rol</th>
            <th>Última conexión</th>
            <th>Estado</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach($usuarios as $u): ?>
        <tr>
            <td><?= htmlspecialchars($u['nombre']) ?></td>
            <td><?= htmlspecialchars($u['email']) ?></td>
            <td><?= htmlspecialchars($u['rol']) ?></td>
            <td><?= $u['ultima_conexion'] ?: 'Nunca' ?></td>

            
            
            <!-- Estado ONLINE/OFFLINE -->
            <td>
                <?php
                    // Si no hay fecha, es Offline
                    if ($u['ultima_conexion'] == null) {
                        echo "<span class='tag is-danger'>Offline</span>";
                    } else {
                        // Calculamos cuanto tiempo pasó (en segundos)
                        $tiempo_pasado = time() - strtotime($u['ultima_conexion']);

                        // Si pasó menos de 300 segundos (5 minutos), está ONLINE
                        if ($tiempo_pasado < 300) {
                            echo "<span class='tag is-success'>Online</span>";
                        } else {
                            echo "<span class='tag is-danger'>Offline</span>";
                        }
                    }
                ?>
            </td>



        </tr>
        <?php endforeach; ?>
    </tbody>
</table>
