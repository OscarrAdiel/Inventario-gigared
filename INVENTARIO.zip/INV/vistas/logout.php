<?php
    // IMPORTANTE: Asegurarnos de que hay una sesión para leer el ID antes de borrarla
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }

    // ====================================================================
    // 1. AVISAR A LA BASE DE DATOS QUE SE FUE (Antes de destruir sesión)
    // ====================================================================
    if(isset($_SESSION['id'])){
        // Ajustamos zona horaria para que coincida con tu sistema (Tijuana)
        date_default_timezone_set('America/Tijuana');
        
        // Incluimos main.php para poder usar la conexión
        //
        require_once "./php/main.php"; 
        
        $pdo = conexion();
        
        // Actualizamos la hora a "hace 1 hora" para forzar el estado OFFLINE inmediato
        $sql = "UPDATE usuarios SET ultima_conexion = DATE_SUB(NOW(), INTERVAL 1 HOUR) WHERE usuario_id = :id";
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute([':id' => $_SESSION['id']]);
    }
    // ====================================================================


    // 2. Liberar todas las variables de sesión
    session_unset();

    // 3. Destruir la sesión completamente
    session_destroy();

    // 4. Redirigir al login
    if(headers_sent()){
        echo "<script> window.location.href='index.php?vista=login'; </script>";
    }else{
        header("Location: index.php?vista=login");
    }
    
    exit();
?>