<?php
    ob_start();

    date_default_timezone_set('America/Mexico_City');
    require_once "./inc/session_start.php";
    
    // ** 1. Incluir el archivo de funciones (main.php) **
    // Esto es necesario para usar la función conexion()
    require_once "./php/main.php";

    if (!isset($_GET['vista']) || $_GET['vista']=="") {
        $_GET['vista'] = "login";
    }

    $vista = $_GET['vista'];

    if (!isset($_SESSION['id']) && $vista != "login" && $vista != "register") {
        header("Location: index.php?vista=login");
        exit();
    }

    if (isset($_SESSION['id']) && ($vista == "login" || $vista == "register")) {
        header("Location: index.php?vista=home");
        exit();
    }
    
    // ** 2. Código CLAVE: Actualizar la última conexión del usuario **
    if (isset($_SESSION['id'])) {
        $pdo = conexion(); // Obtiene la conexión a la DB
        $id_usuario_actual = $_SESSION['id']; 

        try {
            $stmt = $pdo->prepare("UPDATE usuarios SET ultima_conexion = NOW() WHERE usuario_id = :id");
            $stmt->bindParam(':id', $id_usuario_actual);
            $stmt->execute();
        } catch (PDOException $e) {
            // Opcional: Manejar errores de DB aquí si es necesario
            // echo "Error al actualizar conexión: " . $e->getMessage();
        } finally {
            $pdo = null; // Cierra la conexión
        }
    }
    // *******************************************************
?>
<!DOCTYPE html>
<html>
    <head>
        <?php include "./inc/head.php"; ?>
        <link rel="stylesheet" href="estilos.css">
    </head>
    <body>
        <div id="notification-container"></div>

        <?php if(isset($_SESSION['id'])): ?>
        <div id="session-timer" class="tag is-link is-light is-medium">

            <span style="font-weight: bold; margin-right: 15px;">
                <?php echo htmlspecialchars($_SESSION['nombre']); ?>
            </span>

            <span class="icon has-text-info">
                <i class="fas fa-stopwatch"></i>
            </span>
            <span style="font-weight: bold;">Sesión: </span>
            <span id="timer-display" style="font-weight: bold; min-width: 45px;">02:00</span>
        </div>
        <?php endif; ?>

        <?php
            if (is_file("./vistas/".$vista.".php")) {

                $contentClass = "main-content";

                if ($vista != "register" && $vista != "login") {
                    include "./inc/navbar.php";
                } else {
                    $contentClass .= " is-full-width";
                }

                echo '<div class="'.$contentClass.'">';
                include "./vistas/".$vista.".php";
                echo '</div>';

                include "./inc/script.php";

            } else {
                include "./vistas/404.php";
            }
        ?>
    </body>
</html>
<?php ob_end_flush(); ?>
