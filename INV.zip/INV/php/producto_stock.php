<?php
    // Necesario para obtener el ID del usuario para el historial
    require_once "../inc/session_start.php";
    require_once "main.php";

    if(isset($_POST['producto_id']) && isset($_POST['accion'])){
        $id = limpiar_cadena($_POST['producto_id']);
        $accion = limpiar_cadena($_POST['accion']);

        $vista_actual = isset($_POST['vista_actual']) ? limpiar_cadena($_POST['vista_actual']) : "product_list";

        $conexion = conexion();

        // Obtener stock actual
        $consulta = $conexion->query("SELECT producto_stock FROM producto WHERE producto_id='$id'");
        
        if($consulta->rowCount() == 1){
            $stock = (int) $consulta->fetchColumn();

            if($accion=="mas"){
                $nuevo_stock = $stock + 1;
                $mensaje = "agregado";
                // Variables para el historial
                $tipo_movimiento = "Entrada (Manual)";
            }elseif($accion=="menos" && $stock>0){
                $nuevo_stock = $stock - 1;
                $mensaje = "quitado";
                // Variables para el historial
                $tipo_movimiento = "Venta / Salida";
            }else{
                $nuevo_stock = $stock;
                $mensaje = "no_cambio";
                $tipo_movimiento = "";
            }

            // Actualizar en DB
            $update = $conexion->prepare("UPDATE producto SET producto_stock=:stock WHERE producto_id=:id");
            
            if($update->execute([":stock"=>$nuevo_stock, ":id"=>$id])){

                // --- NUEVO: REGISTRAR EN HISTORIAL ---
                // Solo registramos si hubo un cambio real en el stock
                if($nuevo_stock != $stock){
                    $detalles = "Ajuste rápido desde lista: Stock cambió de $stock a $nuevo_stock";
                    registrar_historial($id, $tipo_movimiento, $detalles, $conexion);
                }
                // -------------------------------------

                // Redirigir de vuelta a la lista con mensaje
                header("Location: ../index.php?vista=$vista_actual&msg=".$mensaje);
                exit();
            }else{
                // Error al actualizar
                header("Location: ../index.php?vista=$vista_actual&msg=error");
                exit();
            }

        }else{
            // Producto no encontrado
            header("Location: ../index.php?vista=product_list&msg=error");
            exit();
        }

        $conexion=null;
    }
?>