<?php
require_once "main.php";

$id = limpiar_cadena($_GET['product_id_del']);
$pdo = conexion();

$check = $pdo->prepare("SELECT producto_id FROM producto WHERE producto_id = :id");
$check->execute([':id' => $id]);

if ($check->rowCount() == 1) {
    try {
        $pdo->beginTransaction();

        $stmt = $pdo->prepare("SELECT nombre_archivo FROM producto_imagenes WHERE producto_id = :id");
        $stmt->execute([':id' => $id]);
        $imgs = $stmt->fetchAll(PDO::FETCH_ASSOC);

        foreach ($imgs as $img) {
            $file = "../img/producto/" . $img['nombre_archivo'];
            if (is_file($file)) {
                unlink($file);
            }
        }

        $del_imgs = $pdo->prepare("DELETE FROM producto_imagenes WHERE producto_id = :id");
        $del_imgs->execute([':id' => $id]);

        $del_prod = $pdo->prepare("DELETE FROM producto WHERE producto_id=:id");
        $del_prod->execute([":id" => $id]);

        if ($del_prod->rowCount() == 1) {
            $pdo->commit();
            header("Location: ../index.php?vista=product_list&deleted=ok");
        } else {
            $pdo->rollBack();
            header("Location: ../index.php?vista=product_list&deleted=error");
        }
    } catch (Exception $e) {
        $pdo->rollBack();
        header("Location: ../index.php?vista=product_list&deleted=error");
    }
} else {
    header("Location: ../index.php?vista=product_list&deleted=notfound");
}

$pdo = null;
exit();
?>