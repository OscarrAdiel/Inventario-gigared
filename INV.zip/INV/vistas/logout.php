<?php
    // No es necesario session_start() aquí porque index.php ya lo inició.

    // 1. Liberar todas las variables de sesión
    session_unset();

    // 2. Destruir la sesión completamente
    session_destroy();

    // 3. Redirigir al login
    // Usamos una verificación: si PHP ya envió algo (headers_sent), usamos JS.
    // Si no, usamos la redirección nativa de PHP.
    
    if(headers_sent()){
        echo "<script> window.location.href='index.php?vista=login'; </script>";
    }else{
        // CORREGIDO: Se quitó el "../" porque index.php ya está en la raíz
        header("Location: index.php?vista=login");
    }
    
    exit();
?>